import 'package:flutter/material.dart';
import 'dart:async';


void main() => runApp(TuFolkloreApp());

class TuFolkloreApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tu Folklore',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: PantallaHome(),
    );
  }
}

class PantallaHome extends StatelessWidget {
  final List<String> imagenes = [
    'carnaval1.jpg',
    'carnaval2.jpg',
    'carnaval3.jpg',
    'carnaval4.jpg',
    'carnaval5.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TU FOLKLORE'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PantallaReserva()),
              );
            },
            child: const Text(
              '¿Quieres alquilar tu traje?',
              style: TextStyle(color: Color.fromARGB(255, 25, 1, 1)),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('fondo.jpg'), // Imagen de fondo que deseas
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: CarouselImagenes(imagenes: imagenes),
              ),
            ),
            Image.asset('diablos.jpg'),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'El Carnaval de Oruro, reconocido por la UNESCO como Obra Maestra del Patrimonio Oral e Intangible de la Humanidad, '
                'es una festividad religiosa, folclórica y cultural celebrada en la ciudad boliviana de Oruro. '
                'Se caracteriza por la peregrinación a la Virgen del Socavón, a través de una multitudinaria entrada de danzantes y músicos, '
                'en la que se ejecutan diversas danzas tradicionales.\n\n'
                'La Diablada es una de las danzas más emblemáticas del Carnaval de Oruro, representando el triunfo del bien sobre el mal, '
                'con personajes diabólicos y alegóricos. Otras danzas tradicionales incluyen la Morenada, los Caporales y la Kullawada, '
                'cada una con sus propios trajes, música y coreografía.',
                textAlign: TextAlign.justify,
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                    fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CarouselImagenes extends StatefulWidget {
  final List<String> imagenes;

  const CarouselImagenes({super.key, required this.imagenes});

  @override
  _CarouselImagenesState createState() => _CarouselImagenesState();
}

class _CarouselImagenesState extends State<CarouselImagenes> {
  int _currentPage = 0;
  late PageController _pageController;

@override
void initState() {
  super.initState();
  _pageController = PageController(initialPage: 0);
  _startAutoScroll();
}

void _startAutoScroll() {
  Timer.periodic(const Duration(seconds: 3), (timer) {
    if (_currentPage < widget.imagenes.length - 1) {
      _currentPage++;
    } else {
      _currentPage = 0;
    }
    if (mounted) {
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  });
}

@override
void dispose() {
  _pageController.dispose();
  super.dispose();
}

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: PageView.builder(
        controller: _pageController,
        itemCount: widget.imagenes.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(10),
            child: Image.asset(
              widget.imagenes[index],
              fit: BoxFit.cover,
              width: double.infinity,
              height: 50,
            ),
          );
        },
      ),
    );
  }
}

final Map<String, List<String>> trajesPorDanza = {
  'Caporales': [
    'caporal1.jpg',
    'Caporal2.jpg',
    'Caporal3.jpg',
    'Caporal4.jpg',
    'Caporal5.jpg',
  ],
  'Kullawada': [
    'kullawada1.jpg',
    'kullawada2.jpg',
    'kullawada3.jpg',
    'kullawada4.webp',
    'kullawada5.jpg',
  ],
  'Morenada':[
    'moreno1.jpg',
    'moreno2.webp',
    'moreno3.jpg',
    'moreno4.jpg',
    'moreno5.jpg'

  ],
  'tinku':[
    'tinku1.jpg',
    'tinku2.jpg',
    'tinku3.jpg',
    'tinku4.jpg',
    'tinku5.jpg'
  ],
  'diablada':[
    'diablo1.jpg',
    'diablo2.webp',
    'diablo3.jpg',
    'diablo4.jpg',
    'diablo5.jpg'
  ]
};

final List<String> caracteristicas = [
  'Diseños auténticos',
  'Hecho a mano',
  'Materiales de alta calidad',
  'Comodidad garantizada',
  'Tallas variadas disponibles',
];

final Map<String, String>descripcionTraje = {
  'caporal1.jpg': '\n- Sombrero con plumas o flecos\n- Chaleco bordado a mano\n- Pantalones con apliques de color\n- Botas de cuero\n- Campana en los tobillos que marcan el paso',
  'Caporal2.jpg': '\n- Sombrero multicolor\n- Cinturón de gamuza bordado\n- Casaca muy trabajada\n- Muñequeras con campanas\n- Chaqueta bordada con hilo de oro y plata',
  'Caporal3.jpg': '\n- Traje de Caporal con bordado artesanal\n- Cinturón de cuero\n- Botas de cuero reforzadas\n- Campanas en los tobillos\n- Aplicaciones multicolor',
  'Caporal4.jpg': '\n- Conjunto ligero\n- Danza cómoda y elegante\n- Casaca colorida\n- Sombrero muy vistoso\n- Cinturilla bordada',
  'Caporal5.jpg': '\n- Versión femenina del traje\n- Pollera bordada\n- Blusa bordada\n- Faja colorida\n- Sombrero ornamental',
  
  'kullawada1.jpg': '\n- Sombrero bordado\n- Cinturón andino multicolor\n- Capa corta\n- Bastón de mando\n- Joyería de plata',
  'kullawada2.jpg': '\n- Vestimenta con bordado de figuras aymaras\n- Cinturilla multicolor\n- Muñequeras trabajadas\n- Capa bordada\n- Sombrero de paño',
  'kullawada3.jpg': '\n- Diseño simbólico\n- Detalles brillantes\n- Capa corta multicolor\n- Cinturilla de hilo\n- Sombrero tradicional',
  'kullawada4.jpg': '\n- Incluye gorro bordado\n- Joyería artesanal\n- Cinturón multicolor\n- Muñequeras de hilo\n- Carga de identidad colectiva',
  'kullawada5.jpg': '\n- Modelo estilizado\n- Colores vivos\n- Texturas mixtas\n- Carga de identidad\n- Pasos muy pausados',
  
  'tinku1.jpg': '\n- Traje color verde con estelas amarillas\n- Interior de color celeste que resalta\n- Bordado a mano\n- Cinturilla multicolor\n- Pasos enérgicos',
  'tinku2.jpg': '\n- Montera (casco de cuero)\n- Chaleco de lana o cuero\n- Pantalones de lana\n- Abarcas (sandalias tradicionales)\n- Whipala multicolor',
  'tinku3.jpg': '\n- Carga de fuerza colectiva\n- Pasos contundentes\n- Cinturilla multicolor\n- Muñequeras de hilo\n- Carga de identidad de comunidad',
  'tinku4.jpg': '\n- Combate ritual representado en el paso de la danza\n- Carga de sueños de comunidad\n- Cubrebotas de paño\n- Sombrero muy robusto\n- Carga de coraje y rebeldía',
  'tinku5.jpg': '\n- Carga de identidad colectiva\n- Pasos muy contundentes hacia el suelo\n- Cinturilla multicolor\n- Cubrehombros bordados\n- Sombrero ceremonial',
  
  'diablo1.jpg': '\n- Máscara de diablo muy trabajada\n- Carga de cuernos multicolores o de metal\n- Cinturón con cascabeles y campanas\n- Guantes de metal o de cuero\n- Carga de identidad sincrética',
  'diablo2.webp': '\n- Pasos enérgicos y espectaculares\n- Carga de espuelas o campanas en las botas\n- Muñequeras muy trabajadas\n- Carga de color\n- Carga de mitología colectiva',
  'diablo3.jpg': '\n- Carga de cuernos largos y afilados\n- Carga de perlas, cascabeles y coloridos apliques\n- Máscara que atrae y espanta\n- Guantes de metal\n- Carga de sueños y leyendas',
  'diablo4.jpg': '\n- Carga de identidad sincrética\n- Carga de cuernos de animales míticos\n- Carga de espuelas de metal que marcan el paso\n- Carga de ajuares muy trabajados\n- Carga de muchos sueños de comunidad',
  'diablo5.jpg': '\n- Carga de sincretismo de culturas\n- Carga de fuerza, lucha y rebeldía\n- Carga de color y expresión colectiva\n- Carga de mitología de los Andes\n- Carga de identidad colectiva frente al mundo',

  'moreno1.jpg':'\n',
  'moreno2.jpg':'\n',
  'moreno3.jpg':'\n',
  'moreno4.jpg':'\n',
  'moreno5.jpg':'\n',
};

class PantallaReserva extends StatefulWidget {
  @override
  State<PantallaReserva> createState() => _PantallaReservaState();
}

class _PantallaReservaState extends State<PantallaReserva> {
  String? danzaSeleccionada;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reservar Traje')),
      body: Column(
        children: [
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: trajesPorDanza.keys.map((danza) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() => danzaSeleccionada = danza);
                    },
                    child: Text(danza),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 16),
          danzaSeleccionada == null
              ? const Text('Selecciona una danza para ver los trajes')
              : Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Text(
                          'Trajes de $danzaSeleccionada',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: trajesPorDanza[danzaSeleccionada!]!.map((img) {
                            return GestureDetector(
                              onTap: () {
                                showDialog(
                                  context: context,
                                  builder: (_) => Dialog(
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                    child: Padding(
                                      padding: const EdgeInsets.all(16),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Image.asset('/$img'),
                                          const SizedBox(height: 10),
                                          const Text(
                                            'Detalle del traje',
                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                          ),
                                          const SizedBox(height: 8),
                                          Text(
                                            descripcionTraje[img] ?? 'Descripción no disponible para esta imagen.',
                                            textAlign: TextAlign.justify,
                                          ),
                                          const SizedBox(height: 20),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            children: [
                                              ElevatedButton.icon(
                                                onPressed: () => Navigator.pop(context),
                                                icon: const Icon(Icons.close),
                                                label: const Text('Cerrar'),
                                              ),
                                              ElevatedButton.icon(
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (_) => FormularioReserva(danza: danzaSeleccionada!),
                                                    ),
                                                  );
                                                },
                                                icon: const Icon(Icons.assignment),
                                                label: const Text('Reservar'),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                              child: Image.asset('/$img', width: 100),
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'Características:',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        ...caracteristicas.map((c) => ListTile(
                              leading: const Icon(Icons.check),
                              title: Text(c),
                            )),
                        const SizedBox(height: 20),
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => FormularioReserva(danza: danzaSeleccionada!),
                              ),
                            );
                          },
                          icon: const Icon(Icons.assignment),
                          label: const Text('Reservar este traje'),
                        ),
                      ],
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

class FormularioReserva extends StatefulWidget {
  final String danza;
  const FormularioReserva({super.key, required this.danza});

  @override
  State<FormularioReserva> createState() => _FormularioReservaState();
}

class _FormularioReservaState extends State<FormularioReserva> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nombreCtrl = TextEditingController();
  final TextEditingController telefonoCtrl = TextEditingController();
  final TextEditingController fechaCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Formulario de Reserva')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Text('Reservando traje: ${widget.danza}', style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 16),
              TextFormField(
                controller: nombreCtrl,
                decoration: const InputDecoration(labelText: 'Nombre completo'),
                validator: (value) => value!.isEmpty ? 'Campo obligatorio' : null,
              ),
              TextFormField(
                controller: telefonoCtrl,
                decoration: const InputDecoration(labelText: 'Teléfono'),
                keyboardType: TextInputType.phone,
                validator: (value) => value!.isEmpty ? 'Campo obligatorio' : null,
              ),
              TextFormField(
                controller: fechaCtrl,
                decoration: const InputDecoration(labelText: 'Fecha de uso (ej. 20/02/2025)'),
                validator: (value) => value!.isEmpty ? 'Campo obligatorio' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Reserva exitosa'),
                        content: Text('Gracias ${nombreCtrl.text}, tu traje ha sido reservado.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                            child: const Text('Cerrar'),
                          ),
                        ],
                      ),
                    );
                  }
                },
                icon: const Icon(Icons.check),
                label: const Text('Confirmar Reserva'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
